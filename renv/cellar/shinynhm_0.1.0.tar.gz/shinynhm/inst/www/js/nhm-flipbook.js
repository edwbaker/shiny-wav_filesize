// shinynhm flipbook navigation
(function() {
  'use strict';

  var initialized = {};

  function initAll() {
    document.querySelectorAll('.nhm-flipbook').forEach(function(el) {
      var fbId = el.dataset.flipbookId || 'flipbook';
      if (initialized[fbId]) return;
      initialized[fbId] = true;
      initFlipbook(el);
    });
  }

  function initFlipbook(container) {
    var pages   = container.querySelectorAll('.nhm-flipbook-page');
    var nav     = container.querySelector('.nhm-flipbook-nav');
    if (!pages.length || !nav) return;

    var dotsEl  = nav.querySelector('.nhm-flipbook-dots');
    var labelEl = nav.querySelector('.nhm-flipbook-label');
    var prevBtn = nav.querySelector('.nhm-flipbook-prev');
    var nextBtn = nav.querySelector('.nhm-flipbook-next');
    var current = 0;

    // Hide the regular footer when flipbook is active
    document.documentElement.classList.add('nhm-flipbook-active');

    // Clear any existing dots (in case of re-init)
    dotsEl.innerHTML = '';

    // Build dot indicators
    for (var i = 0; i < pages.length; i++) {
      var dot = document.createElement('button');
      dot.className = 'nhm-flipbook-dot' + (i === 0 ? ' active' : '');
      dot.setAttribute('aria-label', 'Go to page ' + (i + 1));
      dot.dataset.page = i;
      (function(idx) {
        dot.addEventListener('click', function() { goToPage(idx); });
      })(i);
      dotsEl.appendChild(dot);
    }

    function goToPage(idx) {
      if (idx < 0 || idx >= pages.length) return;
      pages[current].classList.remove('active');
      dotsEl.children[current].classList.remove('active');
      current = idx;
      pages[current].classList.add('active');
      dotsEl.children[current].classList.add('active');
      updateNav();

      // Notify Shiny of page change
      if (window.Shiny && window.Shiny.setInputValue) {
        var fbId = container.dataset.flipbookId;
        if (fbId) {
          Shiny.setInputValue(fbId + '_page', current + 1);
        }
      }

      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function updateNav() {
      prevBtn.disabled = (current === 0);
      nextBtn.disabled = (current === pages.length - 1);
      var title = pages[current].dataset.title || '';
      labelEl.textContent = (current + 1) + ' / ' + pages.length +
        (title ? ' \u2014 ' + title : '');
    }

    prevBtn.addEventListener('click', function() { goToPage(current - 1); });
    nextBtn.addEventListener('click', function() { goToPage(current + 1); });

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
      var tag = e.target.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.key === 'ArrowLeft')  goToPage(current - 1);
      if (e.key === 'ArrowRight') goToPage(current + 1);
    });

    updateNav();
  }

  // Try multiple init strategies to handle different load timings
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    // DOM already loaded — run on next tick to let Shiny finish rendering
    setTimeout(initAll, 0);
  }

  // Also init when Shiny signals it's ready
  if (typeof jQuery !== 'undefined') {
    jQuery(document).on('shiny:sessioninitialized', function() {
      setTimeout(initAll, 100);
    });
  }
})();
