.onLoad <- function(libname, pkgname) {
  shiny::addResourcePath(
    prefix = "shinynhm",
    directoryPath = system.file("www", package = "shinynhm")
  )
}

.onUnload <- function(libname) {
  shiny::removeResourcePath("shinynhm")
}
