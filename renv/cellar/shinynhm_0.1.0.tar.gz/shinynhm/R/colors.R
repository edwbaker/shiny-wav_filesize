#' NHM colour palette
#'
#' Returns the NHM theme colour palette as a named list.
#'
#' @return A named list of hex colour strings.
#' @export
nhm_colors <- function() {
  list(
    deep       = "#290340",
    purple     = "#3a0a55",
    card       = "#35104a",
    card_hover = "#4a2668",
    cyan       = "#0AEDF6",
    lime       = "#C8E64A",
    pink       = "#F0A0D0",
    blue       = "#0E17F8",
    brown      = "#8F7E76",
    text       = "#ede8f0",
    muted      = "#a89bb3",
    border     = "#4a2668",
    input      = "#4a2668",
    success    = "#C8E64A",
    danger     = "#e74c3c",
    warning    = "#f39c12"
  )
}
