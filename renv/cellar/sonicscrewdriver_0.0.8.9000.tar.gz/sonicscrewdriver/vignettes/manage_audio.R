## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(sonicscrewdriver)

## -----------------------------------------------------------------------------
filename <- system.file("extdata", "AUDIOMOTH.wav", package="sonicscrewdriver")
readAudio(filename)

